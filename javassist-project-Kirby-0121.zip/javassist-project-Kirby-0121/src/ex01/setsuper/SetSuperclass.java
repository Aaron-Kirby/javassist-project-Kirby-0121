package ex01.setsuper;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

import javassist.CannotCompileException;
import javassist.ClassClassPath;
import javassist.ClassPool;
import javassist.CtClass;
import javassist.NotFoundException;
import target.Rectangle;

public class SetSuperclass {
	static final String SEP = File.separator;
	static String workDir = System.getProperty("user.dir");
	static String outputDir = workDir + SEP + "output";

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String input;
		ArrayList<String> list = new ArrayList<String>();
		boolean needInput = true;
		int count = 1;

		// Get 3 class name imputs
		while (needInput) {
			System.out.printf("Please enter class name #" + count + ". Key \"r\" to run the program: ");
			input = sc.next();

			if (!input.equals("r")) {
				list.add(input);
				count++;
			}

			if (input.equals("r") && list.size() != 3) {
				System.out.println("\n[WRN] Invalid Input");
				list.clear();
				count = 1;
			}
			if (input.equals("r") && list.size() == 3) {
				needInput = false;
			}
		}
		sc.close();
		System.out.println("");

		try {
			ClassPool pool = ClassPool.getDefault();

			boolean useRuntimeClass = true;
			if (useRuntimeClass) {
				insertClassPathRunTimeClass(pool);
			} else {
				insertClassPath(pool);
			}

			// Figure out which is the superclass and which are the subclasses
			if (list.get(0).length() > 5 && list.get(0).substring(0, 6).equals("Common") && list.get(1).length() > 5
					&& list.get(1).substring(0, 6).equals("Common") && list.get(2).length() > 5
					&& list.get(2).substring(0, 6).equals("Common")) {
				if (list.get(0).length() > list.get(1).length() && list.get(0).length() > list.get(2).length()) {
					//make superclass
					CtClass mc = pool.makeClass("target." + list.get(0));
					mc.writeFile(outputDir);
					mc.defrost();
					//make subclasses 1
					CtClass cc = pool.makeClass("target." + list.get(1));
					setSuperclass(cc, "target." + list.get(0), pool);
					cc.writeFile(outputDir);
					cc.defrost();
					//make subclass 2
					CtClass cc2 = pool.makeClass("target." + list.get(2));
					setSuperclass(cc2, "target." + list.get(0), pool);
					cc2.writeFile(outputDir);
					cc2.defrost();
					
					/*CtClass cc = pool.get("target." + list.get(1));
					setSuperclass(cc, "target." + list.get(0), pool);
					cc.writeFile(outputDir);
					cc.defrost();
					System.out.println("[DBG] write output to: " + outputDir);

					CtClass cc2 = pool.get("target." + list.get(2));
					setSuperclass(cc2, "target." + list.get(0), pool);
					cc2.writeFile(outputDir);
					cc2.defrost();
					System.out.println("[DBG] write output to: " + outputDir);*/
				} else if (list.get(1).length() > list.get(0).length()) {
					CtClass cc = pool.get("target." + list.get(0));
					setSuperclass(cc, "target." + list.get(1), pool);
					cc.writeFile(outputDir);
					cc.defrost();
					System.out.println("[DBG] write output to: " + outputDir);

					CtClass cc2 = pool.get("target." + list.get(2));
					setSuperclass(cc2, "target." + list.get(1), pool);
					cc2.writeFile(outputDir);
					cc2.defrost();
					System.out.println("[DBG] write output to: " + outputDir);
				} else {
					CtClass cc = pool.get("target." + list.get(0));
					setSuperclass(cc, "target." + list.get(2), pool);
					cc.writeFile(outputDir);
					cc.defrost();
					System.out.println("[DBG] write output to: " + outputDir);

					CtClass cc2 = pool.get("target." + list.get(1));
					setSuperclass(cc2, "target." + list.get(2), pool);
					cc2.writeFile(outputDir);
					cc2.defrost();
					System.out.println("[DBG] write output to: " + outputDir);
				}
			} else if (list.get(0).length() > 5 && list.get(0).substring(0, 6).equals("Common")
					&& list.get(1).length() > 5 && list.get(1).substring(0, 6).equals("Common")) {
				if (list.get(0).length() > list.get(1).length()) {
					CtClass cc = pool.get("target." + list.get(1));
					setSuperclass(cc, "target." + list.get(0), pool);
					cc.writeFile(outputDir);
					cc.defrost();
					System.out.println("[DBG] write output to: " + outputDir);

					CtClass cc2 = pool.get("target." + list.get(2));
					setSuperclass(cc2, "target." + list.get(0), pool);
					cc2.writeFile(outputDir);
					cc2.defrost();
					System.out.println("[DBG] write output to: " + outputDir);
				} else {
					CtClass cc = pool.get("target." + list.get(0));
					setSuperclass(cc, "target." + list.get(1), pool);
					cc.writeFile(outputDir);
					cc.defrost();
					System.out.println("[DBG] write output to: " + outputDir);

					CtClass cc2 = pool.get("target." + list.get(2));
					setSuperclass(cc2, "target." + list.get(1), pool);
					cc2.writeFile(outputDir);
					cc2.defrost();
					System.out.println("[DBG] write output to: " + outputDir);
				}
			} else if (list.get(0).length() > 5 && list.get(0).substring(0, 6).equals("Common")
					&& list.get(2).length() > 5 && list.get(2).substring(0, 6).equals("Common")) {
				if (list.get(0).length() > list.get(2).length()) {
					CtClass cc = pool.get("target." + list.get(1));
					setSuperclass(cc, "target." + list.get(0), pool);
					cc.writeFile(outputDir);
					cc.defrost();
					System.out.println("[DBG] write output to: " + outputDir);

					CtClass cc2 = pool.get("target." + list.get(2));
					setSuperclass(cc2, "target." + list.get(0), pool);
					cc2.writeFile(outputDir);
					cc2.defrost();
					System.out.println("[DBG] write output to: " + outputDir);
				} else {
					CtClass cc = pool.get("target." + list.get(0));
					setSuperclass(cc, "target." + list.get(2), pool);
					cc.writeFile(outputDir);
					cc.defrost();
					System.out.println("[DBG] write output to: " + outputDir);

					CtClass cc2 = pool.get("target." + list.get(1));
					setSuperclass(cc2, "target." + list.get(2), pool);
					cc2.writeFile(outputDir);
					cc2.defrost();
					System.out.println("[DBG] write output to: " + outputDir);
				}
			} else if (list.get(1).length() > 5 && list.get(1).substring(0, 6).equals("Common")
					&& list.get(2).length() > 5 && list.get(2).substring(0, 6).equals("Common")) {
				if (list.get(1).length() > list.get(2).length()) {
					CtClass cc = pool.get("target." + list.get(0));
					setSuperclass(cc, "target." + list.get(1), pool);
					cc.writeFile(outputDir);
					cc.defrost();
					System.out.println("[DBG] write output to: " + outputDir);

					CtClass cc2 = pool.get("target." + list.get(2));
					setSuperclass(cc2, "target." + list.get(1), pool);
					cc2.writeFile(outputDir);
					cc2.defrost();
					System.out.println("[DBG] write output to: " + outputDir);
				} else {
					CtClass cc = pool.get("target." + list.get(0));
					setSuperclass(cc, "target." + list.get(2), pool);
					cc.writeFile(outputDir);
					cc.defrost();
					System.out.println("[DBG] write output to: " + outputDir);

					CtClass cc2 = pool.get("target." + list.get(1));
					setSuperclass(cc2, "target." + list.get(2), pool);
					cc2.writeFile(outputDir);
					cc2.defrost();
					System.out.println("[DBG] write output to: " + outputDir);
				}
			} else if (list.get(0).length() > 5 && list.get(0).substring(0, 6).equals("Common")) {
				CtClass cc = pool.get("target." + list.get(1));
				setSuperclass(cc, "target." + list.get(0), pool);
				cc.writeFile(outputDir);
				cc.defrost();
				System.out.println("[DBG] write output to: " + outputDir);

				CtClass cc2 = pool.get("target." + list.get(2));
				setSuperclass(cc2, "target." + list.get(0), pool);
				cc2.writeFile(outputDir);
				cc2.defrost();
				System.out.println("[DBG] write output to: " + outputDir);
			} else if (list.get(1).length() > 5 && list.get(1).substring(0, 6).equals("Common")) {
				CtClass cc = pool.get("target." + list.get(0));
				setSuperclass(cc, "target." + list.get(1), pool);
				cc.writeFile(outputDir);
				cc.defrost();
				System.out.println("[DBG] write output to: " + outputDir);

				CtClass cc2 = pool.get("target." + list.get(2));
				setSuperclass(cc2, "target." + list.get(1), pool);
				cc2.writeFile(outputDir);
				cc2.defrost();
				System.out.println("[DBG] write output to: " + outputDir);
			} else if (list.get(2).length() > 5 && list.get(2).substring(0, 6).equals("Common")) {
				CtClass cc = pool.get("target." + list.get(0));
				setSuperclass(cc, "target." + list.get(2), pool);
				cc.writeFile(outputDir);
				cc.defrost();
				System.out.println("[DBG] write output to: " + outputDir);

				CtClass cc2 = pool.get("target." + list.get(1));
				setSuperclass(cc2, "target." + list.get(2), pool);
				cc2.writeFile(outputDir);
				cc2.defrost();
				System.out.println("[DBG] write output to: " + outputDir);
			} else {
				CtClass cc = pool.get("target." + list.get(1));
				setSuperclass(cc, "target." + list.get(0), pool);
				cc.writeFile(outputDir);
				cc.defrost();
				System.out.println("[DBG] write output to: " + outputDir);

				CtClass cc2 = pool.get("target." + list.get(2));
				setSuperclass(cc2, "target." + list.get(0), pool);
				cc2.writeFile(outputDir);
				cc2.defrost();
				System.out.println("[DBG] write output to: " + outputDir);
			}
		} catch (NotFoundException | CannotCompileException | IOException e) {
			e.printStackTrace();
		}
	}

	static void insertClassPathRunTimeClass(ClassPool pool) throws NotFoundException {
		ClassClassPath classPath = new ClassClassPath(new Rectangle().getClass());
		pool.insertClassPath(classPath);
		// System.out.println("[DBG] insert classpath: " + classPath.toString());
	}

	static void insertClassPath(ClassPool pool) throws NotFoundException {
		String strClassPath = workDir + SEP + "bin"; // eclipse compile dir
		// String strClassPath = workDir + SEP + "classfiles"; // separate dir
		pool.insertClassPath(strClassPath);
		System.out.println("[DBG] insert classpath: " + strClassPath);
	}

	static void setSuperclass(CtClass curClass, String superClass, ClassPool pool)
			throws NotFoundException, CannotCompileException {
		curClass.setSuperclass(pool.get(superClass));
		System.out.println("[DBG] set superclass: " + curClass.getSuperclass().getName() + //
				", subclass: " + curClass.getName());
	}
}
